
public class ProjectMain
{

	static String[] testSteps = new String[10];

	public static void main(String[] args)
	{
		System.out.println("****************Writing to the Screen*****************");
		// Problem 1
		System.out.println("This is Panitha Siramshetty");
		// Problem 2
		System.out.println("System.out.print()....This will print the text without adding a line to the console");
		System.out.println("System.out.println()....This will print the text with adding a new line to the console");
		System.out.println("***********************Variables***********************");
		// Problem 1
		int myInt;
		float myFloat;
		String myString;
		boolean myBoolean;
		// Problem 2
		myInt = 25;
		myFloat = 15.0f;
		myString = "some magical words";
		myBoolean = false;
		// Problem 3
		System.out.println("myInt: " + myInt);
		System.out.println("myFloat: " + myFloat);
		System.out.println("myString: " + myString);
		System.out.println("myBoolean: " + myBoolean);

		System.out.println("************************Wrapper Classes***************");
		// Probelm 1
		Integer myotherInt = 50;
		Float myotherFloat = 30.0f;
		String myotherString = "some other words";
		Boolean myotherBoolean = true;
		// Problem 2
		System.out.println("The wrapper class of myotherInt: " + myotherInt.toString());
		System.out.println("The wrapper class of myotherFloat: " + myotherFloat.toString());
		System.out.println("The wrapper class of myotherString: " + myotherString.toString());
		System.out.println("The wrapper class of myotherBoolean: " + myotherBoolean.toString());

		System.out.println("*************************loops************************");
		// Problem 1
		for (int a = 0; a < 10; a++)
		{
			System.out.println("Panitha Siramshetty");
		}
		// Problem 2
		for (int i = 0; i <= 9; i++)
		{
			System.out.println(i);
		}
		System.out.println("***********************if/if-else************************");
		// Problem 1
		for (int i = 0; i < 20; i++)
		{
			if (i >= 10)
			{
				System.out.println(i);
			}

		}
		// Problem 2
		boolean Boolean = true;
		for (int i = 0; i <= 20; i++)
		{
			if (Boolean == true)
			{
				Boolean = false;

			} else
			{
				Boolean = true;
			}
		}

		TestCase testCase = new TestCase();

		System.out.println(testCase.isFinished());
		try
		{
			testCase.run();
		} catch (Exception e)
		{
			System.out.println(" An exception was triggered: " + e.getMessage());
		}
		System.out.println(testCase.isFinished());
	}

}
