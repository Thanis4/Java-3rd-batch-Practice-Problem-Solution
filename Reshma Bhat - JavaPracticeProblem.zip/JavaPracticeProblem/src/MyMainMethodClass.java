
public class MyMainMethodClass {
	
	
	
	public static void main(String[] args)
	{
		System.out.println("Reshma Bhat - printed using System out println");
		
		System.out.print("This ");
		System.out.print("line ");
		System.out.print("was ");
		System.out.print("printed ");
		System.out.print("using ");
		System.out.print("System ");
		System.out.print("out ");
		System.out.println("print.");
		
		System.out.println("****************************************************************************************************");
		
		//Difference between System.out.print and System.out.println is that the command System.out.print will not add a new line
		
		int i = 10;
		float f = 12.5f;
		String s = "My String";
		boolean b = true;
		
		System.out.println("The value of i = " + i);
		System.out.println("The value of f = " + f);
		System.out.println("The value of s = " + s);
		System.out.println("The value of b = " + b);
		
		System.out.println("****************************************************************************************************");
		
		Integer I = 77;
		Float F = 24.55f;
		String S = "Second String";
		Boolean B = false;
		
		System.out.println("The value of wrapper I = " + I.toString());
		System.out.println("The value of wrapper F = " + F.toString());
		System.out.println("The value of wrapper S = " + S.toString());
		System.out.println("The value of wrapper B = " + B.toString());
		
		System.out.println("****************************************************************************************************");
		
		for (int a=1; a<=10; a++)
		{
			System.out.println(a + " Reshma Bhat");
			
		}
		
		System.out.println("****************************************************************************************************");
		
		for (int a=0; a<10; a++)
		{
			System.out.println(a);
			
		}
		
		System.out.println("****************************************************************************************************");
		
		System.out.println("Printing only the values that are greater than or equal to 10");
		for (int a=1; a<=20; a++)
		{
			if (a>=10)
				System.out.println(a);
		}
		
		System.out.println("****************************************************************************************************");
		
		boolean invertBoolean = false; 
		
		for (int a=1; a<=20; a++)
		{
		  if (invertBoolean == false)
		  {
			  invertBoolean = true;  
		  }
		  
		  else
		  {
			  invertBoolean = false;
		  }
		  
		  System.out.println("Now the Boolean value is: " + invertBoolean);
		  		  
		}
		
		System.out.println("****************************************************************************************************");
		
		TestCase testCase1 = new TestCase();
		
		System.out.println("Test case run complete: " + testCase1.isFinished());
		
		try
		{
		testCase1.run();
		}
		
		catch (Exception e)
		{
			System.out.println("An exception was encountered  " + e.getMessage());
		}
		
		
		System.out.println("Test case run complete: " + testCase1.isFinished());
		
	    
	}

}
