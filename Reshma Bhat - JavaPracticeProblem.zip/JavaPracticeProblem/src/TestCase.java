public class TestCase 
{
	
	private String[] testSteps = new String[10];
	  
	private String description = "";
	
	private boolean isFinished = false;
	
	public boolean isFinished()
	{
		return isFinished;
	}


	public TestCase()
	{
	testSteps[0] = "Step1- Go to URL";
	testSteps[1] = "   Step2- Enter username    ";
	testSteps[2] = "Step3- Enter password";
	testSteps[3] = "Step4- Click Submit button";
	testSteps[4] = "   Step5- Ensure next page is displayed ";
	testSteps[5] = "  Step6- Click on tab1";
	testSteps[6] = "Step7- Ensure all tab1 components are displayed correctly     ";
	testSteps[7] = "Step8- Click on tab2";
	testSteps[8] = "Step9- Ensure all tab2 components are displayed correcyly";
	testSteps[9] = "Step10- Log out";
	}
	

	public void run() throws Exception
	{
		for (int e=0; e<testSteps.length; e++)
		{
			System.out.println(testSteps[e]);
		}
		
		System.out.println("****************************************************************************************************");
		System.out.println("After trimming the white space in the test steps, below is the output");
		System.out.println();
		
		for (int e=0; e<testSteps.length; e++)
		{
			System.out.println(testSteps[e].trim());
		}
		
		isFinished = true;
		
		throw new Exception("\"This is a scary exception\"");
		
	}
	
	@Override
	public String toString()
	{
		int x = testSteps.length;
		String result = String.format("Test Case{%s | number of steps: %d | complete: %b}", description, x, isFinished);
		//return (description + " " + testSteps.length + " " + isFinished);
	    return result;
	}
	
}

