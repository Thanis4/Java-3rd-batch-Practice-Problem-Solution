
/**
* 
 */

/**
* this for the Java 1 Practice Problems
* @author JALANP3
*
*/
public class ProjectMain {

       static String[] strMySteps = new String[10];
       
       /**
       * @param args
       */
       public static void main(String[] args) {
              // Problem 1. print your name from the main method

              System.out.println("Pooja Jalan");
              System.out.println("\n");
              
              //Problem 2. explain the difference between System.out.println() and System.out.print()
              
              System.out.println("Println is use to show in newline");
              System.out.print("print is without the space");
              System.out.println("\n");
              System.out.print("here is the outcome");
       
              System.out.println("\n");
              //Problem 1. make an int, a float, a String, and a boolean variable.
              //Problem 2. give each of the 4 variables above an appropriate value (remember, java treats 1.0 as a double and not a float)
              //Problem 3. print the variable names and their values using System.out.println()
              
              int anInt = 20;
              float aFloat = 0.4f;
              String aString = "My Value";
              boolean aBoolean = true;
              
              System.out.println("myInt: " + anInt);
              System.out.println("myFloat: " + aFloat);
              System.out.println("myBoolean: " + aBoolean);
              System.out.println("myString: " + aString);
              
              System.out.println("\n");
              //wrapper classes
              //Problem 1. make duplicate versions of the 4 variables from variables: Problem 1, with different names, using the wrapper classes
              //Problem 2. print the name and value of each variables (Integer, String, Float, Boolean) using the wrapper class ".toString()" method and System.out.println()
              
              Integer myOtherInt = 20;
              Float myOtherFloat = 20.4f;
              Boolean myOtherBoolean = false;

              System.out.println("myOtherInt:" + myOtherInt.toString());
              System.out.println("myOtherFlot:" + myOtherFloat.toString());
              System.out.println("myBoolen:" + myOtherBoolean.toString());
              
              System.out.println("\n");
              
              //loops Problem 1. using a simple for loop (type "for" then hit Ctrl+Space), print your name 10 times
              
              for (int i = 0; i <10; i++) {
                     System.out.println("Pooja Jalan");
              }
              System.out.println("\n");
              //Problem 2. using a simple for loop, print the values 0 to 9 (use System.out.println() inside the loop)
              
              for (int i = 0; i<10; i++) {
                     System.out.println(i);
              }
              
              System.out.println("\n");
              
              //Problem 1. using a simple for loop, loop through the values 1 to 20 but only
              //print values larger than or equal to 10. use an if statement to determine if the value is larger
              
              for (int i = 1; i <=20; i++) {
                     
                     if (i>=10) {                             
                                  System.out.println(i);
              }
              }
              System.out.println("\n");
              
              //Problem 2. using a simple for loop, loop through the values 1 to 20. 
              //make a boolean outside the loop with a value of false, and invert it's value
              //(true becomes false, false becomes true) during the loop (use an if-else statement to check it's
              //value and set it appropriately)
              
              boolean myBoolen = false;

              for (int i = 1; i <= 20; i++)
              {
              if (myBoolen == false)
              {
              myBoolen = true;
              }
              else
              {
              myBoolen = false;
              }
              
              }
              System.out.println(myBoolen);
              System.out.println("\n");
              
              //Problem 1. make a String array with size 10, add 1 made-up test step at each index of the array. 
              //print each step by accessing it from the array. hint: System.out.println(stringArray[index]); 
              //this code will be used later.
              
              /*String[] strMySteps = new String[10];*/
              strMySteps[0] = "Step 1. Open a browser";
              strMySteps[1] = "Step 2. Navigate to http://www.amazon.com";
              strMySteps[2] = "Step 3. Search: vacuum cleaner";
              strMySteps[3] = "Step 4. Validate the price at $559.99";
              strMySteps[4] = "Step 5. Click more options";
              strMySteps[5] = "Step 6. look for more color options ";
              strMySteps[6] = "Step 7. Click the Buy Now button";
              strMySteps[7] = "Step 8. Enter Billing and Shipping information";
              strMySteps[8] = "Step 9. Click the Submit Order button";
              strMySteps[9] = "Step 10. Email mail confirmation";
              
              System.out.println("#### From main() ####");
              for (int i = 0; i < strMySteps.length; i++)
              {                    System.out.println(strMySteps[i]);
              }
              System.out.println("/n");
       //Problem 1. make a function with the following signature: public void run()
       //This function should loop through the array above and print each test step. This code will be used later.
                     
      /* public void run()
       {*/
              for (int i = 0; i < strMySteps.length; i++)
              {
              System.out.println(strMySteps[i]);
       }
              
              System.out.println("/n");
              
              // Problem 2. in main, make an instance of the TestCase class and
              // print the value of isFinished (hint: use the getter above).
              // then call run() to print the steps, then print the value of isFinished again.
              
              TestCase myTestCase = new TestCase();
              System.out.println("#### From TestCase--run() ####");
              System.out.println("isFinished--> " + myTestCase.isFinished());
              try {
              myTestCase.run();
              } catch (Exception e) {
                     System.out.println("Exception from test run in main(): " + e.toString());
              }
              System.out.println("isFinished--> " + myTestCase.isFinished());
              
              System.out.println("\n");
       
       }// end main
       
       // Problem 1. make a function with the following signature: public void run()
       // This function should loop through the array above and print each test step.
       // This code will be used later.
       
       /**
       * for methods/functions use
       */
       /*public void run() {
              System.out.println("From run()...");
              for (int i = 0; i < strMySteps.length; i++) {
                     System.out.println(strMySteps[i]);

              }
       }      //end run
              
*/
}      //EOF
              
       


