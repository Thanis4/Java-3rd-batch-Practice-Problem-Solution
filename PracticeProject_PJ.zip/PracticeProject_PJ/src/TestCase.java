/**
 * This class is created for 'classes' practice problem
 * @author Pooja Jalan
 *
 */
public class TestCase {
	private String description = "";
	private String[] strMySteps = new String[10];
	private boolean isFinished = false;
	
	public TestCase() {
		strMySteps[0] = "Step 1. Open a browser";
		strMySteps[1] = "Step 2. Navigate to http://www.amazon.com";
        strMySteps[2] = "         Step 3. Search: vacuum cleaner";
        strMySteps[3] = "Step 4. Validate the price at $559.99    ";
        strMySteps[4] = "Step 5. Click more options";
        strMySteps[5] = "Step 6. look for more color options ";
        strMySteps[6] = "      Step 7. Click the Buy Now button";
        strMySteps[7] = "Step 8. Enter Billing and Shipping information";
        strMySteps[8] = "     Step 9. Click the Submit Order button";
        strMySteps[9] = "Step 10. Email mail confirmation      ";

	}
	
	/**
	 * Problem 1. make a new class called TestCase. it should contain: a String
	 * named description move the testSteps array from the arrays section to this
	 * class. Insert values in the constructor. add a public method called run()
	 * with a void return value that prints out each step in the testSteps array
	 * (see methods/functions for code)
	 */
	public void run() throws Exception {
		for (int i = 0; i < strMySteps.length; i++) {
			System.out.println(strMySteps[i].trim());
		}
		
		isFinished = true;
		description = "My Test Case";
		System.out.println(this.toString());
		throw new Exception("Done printing all test steps...");
	} // end run
	
	
	@Override
	public String toString() {
		// String strReturn = description + "--" + strTestSteps.length + "--" + isFinished;
		String myFormat = "TestCase{%s | number of steps: %d | complete: %b}";
		String strReturn = String.format(myFormat, description, strMySteps.length, isFinished);
		return strReturn;
	}

	public boolean isFinished() {
		return isFinished;
	}

} // EOF
