public class TestCase2
{
	private String[] tstSteps = new String[10];
	private String description = "";
	private boolean isFinished = false;
	
	public TestCase2()
		{
// problem 1
		tstSteps[0] = "Step 1. Open a browser ";
		tstSteps[1] = " Step 2. Navigate to http://www.thinkgeek.com";
		tstSteps[2] = "Step 3. Search: Zelda Triforce Cookie Container";
		tstSteps[3] = "Step 4. Validate the price at $59.99";
		tstSteps[4] = " Step 5. Click the Buy Now button ";
		tstSteps[5] = "Step 6. Verify the INSTOCK checkmark";
		tstSteps[6] = "Step 7. Click the Go to Checkout! button";
		tstSteps[7] = "Step 8. Enter Billing and Shipping information ";
		tstSteps[8] = "Step 9. Click Go to Checkout button";
		tstSteps[9] = " Step 10. Click the Submit Order button";
		}
	public void run()
	{
		for (int i = 0; i < tstSteps.length; i++)
		{
			// problem 2
			System.out.println(tstSteps[i].trim());
		}
		isFinished = true;
	}
	public boolean isFinished()
	{
		return isFinished;
	}
// problem 3
/*@Override solution 
	public String toString()
		{
		String format = "TestCase{%s | number of steps: %d | complete: %b}";
		String output = String.format(format, description,
				tstSteps.length, isFinished);
		return output;
		}*/
	}