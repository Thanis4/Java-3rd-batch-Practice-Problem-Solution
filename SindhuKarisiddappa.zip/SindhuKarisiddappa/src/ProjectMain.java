public class ProjectMain {

	public static void main(String[] args)	
	{
		int x = 4;
		float y = 4.0f;
		String z = "test";
		boolean a = true;
				
		System.out.println("Sindhu Prakash"); // writing to the screen Problem 1.
		System.out.print("Sindhu Prakash"); // writing to the screen Problem 2 - prints in new line 
		
		System.out.println("x: " + x); // variables Problem  1, 2,3 
		System.out.println("y: " + y);	
		System.out.println("z: " + z);	
		System.out.println("a: " + a);	
		
		// Wrapper Class problem 1
		
		Integer differentInt = 20;
		Float differentFloat = 14.0f;
		String differentString = "some other words";
		Boolean differentBoolean = true;
		// Wrapper Class problem 2
		System.out.println("differentInt: " + differentInt.toString());
		System.out.println("differentFloat: " + differentFloat.toString());
		System.out.println("differentString: " + differentString.toString());
		System.out.println("differentBoolean: " + differentBoolean.toString());
	
		
		int max = 10;    // loops Problem  1 
		
		for (int i = 1; i <= max; i++)
		{
			System.out.println("Sindhu Prakash");
		}
		
		int min =9;  // loops Problem  2
		for (int j = 1; j <= min; j++)
		{
			System.out.println("j:" + j );
		}
		for (int k = 1; k <= 10; k++)
		{
			if (k <= 10) //	If\if -else Problem 1
		{
			System.out.println("k:" + k);
			
		}
		}
				
	//	If\if -else Problem 2 
		boolean value = true;
				for (int l = 1; l <= 20; l++)
		{
			if (value == true)
			{
				value = false;
				System.out.println("value:" + value);
			}
			else 
			{
				value = true;
			}
		
		}
		
				//Arrays Problem 1 
				String[] test = new String[10];
				test[0] = "Launch the browser";
				test[1] = "Launch the application";
				test[2] = "Login to TD online banking as small business user";
				test[3] = "Click on billpay";
				test[4] = "verify on payee";
				test[5] = "verify on payee detail";
				test[6] = "verify on billpay settings";
				test[7] = "Click on bill tab";
				test[8] = "select the to and from accounts";
				test[9] = "Click on Pay bill";
		
				
	// problem 2
	/*		TestCase testCase = new TestCase();
			System.out.println(testCase.isFinished());
			testCase.run();
			System.out.println(testCase.isFinished());
				}*/
	
	TestCase testCase = new TestCase();
	System.out.println(testCase.isFinished());
	// problem 2
	try
	{
	testCase.run();
	}
	catch (Exception exe)
	{
	// problem 3
	System.out.println(" An exception was triggered: " + exe.getMessage());
	}
	System.out.println(testCase.isFinished());

			

		//String regexPattern = "[0-9]{3}-[0-9]{3}-[0-9]{3}";
						
		// TODO Auto-generated method stub
	
		/*USSS-799 POST�/v1/selfserve/failureattempts/statusint myint =5;
		float myfloat=5.4f;
		boolean booleanmy=true;
		
		System.out.println("myint: " + myint);		
		System.out.println("myfloat: " + myfloat);
		System.out.println("booleanmy:" + booleanmy);
				*/
		
	/*	int myint1 = 6;
		float myfloat1 = 6.7f;
		boolean myboolean1 = true;
		
		/*System.out.println("integer myint1: " + myint1 );
		System.out.println(" float myfloat1: " +  myfloat1);
		System.out.println(" boolean myboolean1: "+  myboolean1);	
		System.out.println("integer myint1: ");
		
	if (myint1 > 8)
		{
			System.out.println("myint1 is greater");
		}
		else 
		{
			System.out.println("myint1 is smaller");
		}
		
		
		System.out.println("hello World!");
		
		System.out.println("Sindhu Prakash");
	}*/
	
		/*float temp = 0.5f;
		
		if ( temp > 30.0f)
		{
			System.out.println("temperature is :" + temp + ". Too Hot!");			
		}
		else if  ( temp < 15.0f)
		{
			System.out.println("temperature is :" + temp + " .Too cold!");
		}
		else 
		{
			System.out.println("temperature is :" + temp+" . Just Right!");
		}*/
			
		/*TestCase tc = new TestCase();	
		TestCase tc2 = new TestCase();

		tc.description = "new_decsription";
		
		System.out.println(tc.description);
		System.out.println(tc2.description);*/
		
		/*String Name = "   SindhuPrakash  ";
		String trimmedName = Name.trim (); 
		System.out.println(trimmedName);  
	
		int age = 35;
		String message = String.format("My name is %s and I am %d years old", trimmedName,age);
		System.out.println(message); */
		
	/*	String regexPattern = "[0-9]{3}-[0-9][a-z]{3}-[0-9]{4}";
		String phonenumber = "200-a64-8752";
		Boolean regexMatched = phonenumber.matches(regexPattern);
		String pattern = " \"%s\" matches \"%s\": %b";
		String output = String.format(pattern, phonenumber,regexPattern,regexMatched);
		System.out.println(output);*/ 
		
		
	/*	String nullstring = null;
		
		try 
		{
		nullstring.isEmpty();
		}
		
		catch (NullPointerException nullPntexe)
		{
			//System.out.println("catch the exception");
			nullPntexe.printStackTrace();
			System.out.println(nullPntexe.getMessage());
			nullstring = "test";
			
		}
		System.out.println(nullstring.isEmpty());*/
		}
	
	
}
			

