public class TestCase
{
	// problem 1
	private String[] teststep = new String[10];
	private String description = "";
	private boolean isFinished = false;
	
	public TestCase()
	{
		teststep[0] = "Launch the Browser";
		teststep[1] = "click 123";
		teststep[2] = "Login to TD online banking as retail user";
		teststep[3] = "Click on accounts";
		teststep[4] = "verify on account summary";
		teststep[5] = "verify on account detail";
		teststep[6] = "verify on account settings";
		teststep[7] = "Click on transfers tab";
		teststep[8] = "select the to and from accounts";
		teststep[9] = "Click on tranfer - Submit the transfer";
		
	}
	public void run()
	{
		for (int i = 0; i < teststep.length; i++)
		{	
			System.out.println(teststep[i]);
		}
		isFinished = true;
	}
	public boolean isFinished()
	{
		return isFinished;
	}
	// problem 3
	@Override
	public String toString()
	{
		String output = description + " " + teststep.length + " " +
				isFinished;
		return output;
	}
	}
