	public class TestCase3
		{
		private String[] testSteps = new String[10];
		private String description = "";
		private boolean isFinished = false;
		
		public TestCase3()
		  {
			testSteps[0] = "Step 1. Open a browser ";
			testSteps[1] = " Step 2. Navigate to http://www.thinkgeek.com";
			testSteps[2] = "Step 3. Search: Zelda Triforce Cookie Container";
			testSteps[3] = "Step 4. Validate the price at $59.99";
			testSteps[4] = " Step 5. Click the Buy Now button ";
			testSteps[5] = "Step 6. Verify the INSTOCK checkmark";
			testSteps[6] = "Step 7. Click the Go to Checkout! button";
			testSteps[7] = "Step 8. Enter Billing and Shipping information ";
			testSteps[8] = "Step 9. Click Go to Checkout button";
			testSteps[9] = " Step 10. Click the Submit Order button";
			}
// problem 1
		public void run() throws Exception
		{
			for (int i = 0; i < testSteps.length; i++)
			{
				System.out.println(testSteps[i].trim());
			}
			isFinished = true;
				throw new Exception("All Test Steps complete");
			}
		public boolean isFinished()
		{
			return isFinished;
		}
@Override
	public String toString()
		{
		String format = "TestCase{%s | number of steps: %d | complete: %b}";
		String output = String.format(format, description,testSteps.length, isFinished);
		return output;
}
}