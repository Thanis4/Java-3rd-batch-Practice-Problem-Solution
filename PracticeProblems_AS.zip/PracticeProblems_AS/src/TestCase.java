/**
 * This class is created for 'classes' practice problem
 * @author SAWANA4
 *
 */
public class TestCase {
	private String description = "";
	private String[] strTestSteps = new String[10];
	private boolean isFinished = false;
	
	public String getDescription() {
		return description;
	}

	public String[] getStrTestSteps() {
		return strTestSteps;
	}

	public boolean isFinished() {
		return isFinished;
	}

	public TestCase() {
		strTestSteps[0] = "Step1--> Open URL google.com";
		strTestSteps[1] = "      Step2--> Enter 'chicken salad sandwich recipe' in search field ";
		strTestSteps[2] = "Step3--> Scroll below until you find the link 'Chicken Salad Sandwiches Recipe - BettyCrocker.com'";
		strTestSteps[3] = "Step4--> Click on the link 'Chicken Salad Sandwiches Recipe - BettyCrocker.com'";
		strTestSteps[4] = "Step5--> Gather ingredients mentioned in the 'Ingredients' section";
		strTestSteps[5] = "      Step6--> Follow the steps from the 'Steps' section to make the sandwich";
		strTestSteps[6] = "Step7--> Place the sandwich on a plate     ";
		strTestSteps[7] = "Step8--> Place the plate containing sandwich on the table";
		strTestSteps[8] = "Step9--> Sit on the chair      ";
		strTestSteps[9] = "Step10--> Enjoy the sandwich!!!!";
	}
	
	/**
	 * Problem 1. make a new class called TestCase. it should contain: a String
	 * named description move the testSteps array from the arrays section to this
	 * class. Insert values in the constructor. add a public method called run()
	 * with a void return value that prints out each step in the testSteps array
	 * (see methods/functions for code)
	 */
	public void run() throws Exception {
		for (int i = 0; i < strTestSteps.length; i++) {
			System.out.println(strTestSteps[i].trim());
		}
		
		isFinished = true;
		description = "My Test Case";
		System.out.println(this.toString());
		throw new Exception("Done printing all test steps...");
	} // end run
	
	
	@Override
	public String toString() {
		// String strReturn = description + "--" + strTestSteps.length + "--" + isFinished;
		String myFormat = "TestCase{%s | number of steps: %d | complete: %b}";
		String strReturn = String.format(myFormat, description, strTestSteps.length, isFinished);
		return strReturn;
	}

} // EOF
