/**
 * This class is the main class for PracticeProblems_AS project
 * 
 * @author SAWANA4
 *
 */
public class ProjectMain {
	
	static String[] strMySteps = new String[10];

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Problem 1. print your name from the main method
		System.out.println("Ashwini Sawant");
		System.out.println("****************************");

		// Problem 2. explain the difference between System.out.println() and
		// System.out.print()
		System.out.println("System.out.println--> prints output and then adds a newline character at the end");
		System.out.print("System.out.print-->prints output but does not add newline...");
		System.out.print("as a result this line is printed on the same line");
		System.out.print("\n");
		System.out.println("****************************");

		// Problem 1. make an int, a float, a String, and a boolean variable
		// Problem 2. give each of the 4 variables above an appropriate value (remember,
		// java treats 1.0 as a double and not a float)
		int myInt = 10;
		float myFloat = 2.5f;
		String myString = "My String";
		boolean myBool = true;

		// Problem 3. print the variable names and their values using
		// System.out.println()
		System.out.println("myInt-->" + myInt);
		System.out.println("myFloat-->" + myFloat);
		System.out.println("myString-->" + myString);
		System.out.println("myBool-->" + myBool);
		System.out.println("****************************");

		// Problem 1. make duplicate versions of the 4 variables from variables: Problem
		// 1, with different names, using the wrapper classes
		myInt = 15;
		myFloat = 5.0f;
		myBool = false;
		
		Integer iMyInt = new Integer(myInt);
		Float fMyFloat = new Float(myFloat);
		Boolean bMyBool = new Boolean(myBool);
		
		// Problem 2. print the name and value of each variables (Integer, String,
		// Float, Boolean) using the wrapper class ".toString()" method and
		// System.out.println()
		System.out.println("iMyInt-->" + iMyInt.toString());
		System.out.println("fMyFloat-->" + fMyFloat.toString());
		System.out.println("bMyBool-->" + bMyBool.toString());
		System.out.println("****************************");
		
		// Problem 1. using a simple for loop, print your name 10 times
		for (int i = 1; i <= 10; i++) {
			System.out.println(i + "-->" + "Ashwini Sawant");
		}

		System.out.println("****************************");

		// Problem 2. using a simple for loop, print the values 0 to 9 (use
		// System.out.println() inside the loop)
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}

		System.out.println("****************************");

		// Problem 1. using a simple for loop, loop through the values 1 to 20 but only
		// print values larger than or equal to 10. use an if statement to determine if
		// the value is larger
		for (int i = 1; i <= 20; i++) {
			if (i >= 10) {
				System.out.println(i);
			}
		}

		System.out.println("****************************");

		// Problem 2. using a simple for loop, loop through the values 1 to 20. make a
		// boolean outside the loop with a value of false, and invert it's value (true
		// becomes false, false becomes true) during the loop (use an if-else statement
		// to check it's value and set it appropriately)
		boolean bFlag = false;
		for (int i = 1; i <= 20; i++) {
			if(bFlag == false) {
				bFlag = true;
			} else {
				bFlag = false;
			}
		}
		System.out.println("bFlag Final-->" + bFlag);
		System.out.println("****************************");
		
		// Problem 1. make a String array with size 10, add 1 made-up test step at each
		// index of the array. print each step by accessing it from the array. hint:
		// System.out.println(stringArray[index]); this code will be used later.
		/*String[] strMySteps = new String[10];*/
		strMySteps[0] = "Step1--> Open URL google.com";
		strMySteps[1] = "    Step2--> Enter 'chicken salad sandwich recipe' in search field ";
		strMySteps[2] = "Step3--> Scroll below until you find the link 'Chicken Salad Sandwiches Recipe - BettyCrocker.com'";
		strMySteps[3] = "Step4--> Click on the link 'Chicken Salad Sandwiches Recipe - BettyCrocker.com'";
		strMySteps[4] = "Step5--> Gather ingredients mentioned in the 'Ingredients' section";
		strMySteps[5] = "    Step6--> Follow the steps from the 'Steps' section to make the sandwich";
		strMySteps[6] = "Step7--> Place the sandwich on a plate    ";
		strMySteps[7] = "Step8--> Place the plate containing sandwich on the table";
		strMySteps[8] = "Step9--> Sit on the chair    ";
		strMySteps[9] = "Step10--> Enjoy the sandwich!!!!";

		System.out.println("#### From main() ####");
		for (int i = 0; i < strMySteps.length; i++) {
			System.out.println(strMySteps[i]);
		}
		
		System.out.println("****************************");
		
		// Problem 2. in main, make an instance of the TestCase class and
		// print the value of isFinished (hint: use the getter above).
		// then call run() to print the steps, then print the value of isFinished again.

		TestCase myTestCase = new TestCase();
		System.out.println("#### From TestCase--run() ####");
		System.out.println("isFinished--> " + myTestCase.isFinished());
		try {
		myTestCase.run();
		} catch (Exception e) {
			System.out.println("Exception caught in main(): " + e.toString());
		}
		System.out.println("isFinished--> " + myTestCase.isFinished());
		
		System.out.println("****************************");

	} // end main
	
	// Problem 1. make a function with the following signature: public void run()
	// This function should loop through the array above and print each test step.
	// This code will be used later.
	
	/**
	 * for methods/functions use
	 */
	/*public void run() {
		System.out.println("From run()...");
		for (int i = 0; i < strMySteps.length; i++) {
			System.out.println(strMySteps[i]);
		}
	} // end run
*/	
} // EOF
