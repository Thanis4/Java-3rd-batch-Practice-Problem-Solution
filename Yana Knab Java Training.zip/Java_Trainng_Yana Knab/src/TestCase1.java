
public class TestCase1 
{
	
	private String[] TestString = new String[10];
	private boolean isFinished = false;
	private String description ="";
	
	// methods/functions	 Problem 1. 
	public TestCase1()
	{
		
		 TestString[0]= "       open browser two";
		 TestString[1]= "open application";
		 TestString[2]= "enter user name " ;
		 TestString[3]= "enter password";
		 TestString[4]= "enter token ID";
		 TestString[5]= "click submit";
		 TestString[6]= "navigate to settings";
		 TestString[7]= "verify settings";
		 TestString[8]= "close application";
		 TestString[9]= "close browser";
		 
	}

	//Problem 1. modify the run() method on TestCase to throw a new exception when all the steps are printed.
	public void run() throws Exception
	{
		System.out.println("length:"+TestString.length+"*********");
	for (int i =0; i < TestString.length; i++)
	    {
	       System.out.println(TestString[i].trim());
	       throw new Exception("All  Steps are completed");
	    }
	isFinished= true;
	
    }

	
	public boolean isFinished() {
		return isFinished;
	}
	@Override
	public String toString()
	{
		String format = "TestCase{%s | number of steps: %d | complete: %b}";
		String output = String.format(format, description,
		TestString.length, isFinished);
	return output;
	}

	

}
