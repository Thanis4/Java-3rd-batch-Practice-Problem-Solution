
public class ProjectMain {
	static String[] TestString = new String[10];
	public static void main(String[] args) {
	// Writing to the screen . 
		//Problem1 .Print your name .
	   
		System.out.println("Yana Knab");
		System.out.print("Yana Knab");
		
		// Problem 2 .Explain the difference between System.out.println() and System.out.print()
	  /*	
	   Print method prints the text on the console and the cursor remains at the end of the text at the console. 
	   The next printing takes place from just here.
	   
	   Println prints the text on the console and the cursor remains at the start of the next line at the console. 
	   The next printing takes place from next line.
	 */	 
		
	//Variables . 
		//Problem 1- make an int, a float, a String, and a boolean variable.
		int i;
	    float f;
		String s;
		Boolean b;
		// Problem 2 -give each of the 4 variables above an appropriate value
		i=4;
		f=3.3f;
		s="Hello";
		b= true;
		
		// Problem 3 - print the variable names and their values using System.out.println()
		
		System.out.println("\ni "+i + "\nf "+f + "\ns "+ s + "\nb "+ b);
		
	// wrapper classes
		// Problem 1 .Make duplicate versions of the 4 variables from variables:
		//Problem 1, with different names, using the wrapper classes
		 Integer myInt = 40;
		 Float myFloat =6.6f;
		 String myString = "Hello again";
		 Boolean myBoolean = false;
		 
		// Problem 2. print the name and value of each variables (Integer, String, Float, Boolean) using the wrapper class ".toString()" method and System.out.println()
		 System.out.println("myInt "+ myInt.toString());
		 System.out.println("myFloat "+ myFloat.toString());
		 System.out.println("myString "+ myString.toString());
		 System.out.println("myBoolean "+ myBoolean.toString());
		 
		 
	//loops
		 // Problem 1 . using a simple for loop , print your name 10 times
		 for (int j = 0; j < 10; j++) {
			 System.out.println("Yana");
			
		}
		 // Problem 2 . using a simple for loop , print the values 0 to 9 
		 for (int j = 0; j < 10; j++) {
			 System.out.println(j);
		}
		 
	//if/if-else
		 //Problem 1 using a simple for loop, loop through the values 1 to 20 but only print values larger than or equal to 10.
		 for (int j = 1; j <= 20; j++) {
			 if (j>=10) {
				 System.out.println(j);
			 }
		 }			 
		  // Problem 2 using a simple for loop, loop through the values 1 to 20. make a boolean outside the loop with a value of false,
		  // and invert it's value during the loop 
			 boolean myB =false; 
			 System.out.println(myB);
			 for (int count = 1; count<=20; count++)
			 {
				if (myB==false) 
				{
					myB =true;
					
				} 
				else 
				{
                     myB=false;
                   
				} 
				
			}
			 /*arrays
			   Problem 1. make a String array with size 10, 
			 add 1 made-up test step at each index of the array. print each step by accessing it from the array.
*/
			
			         TestString[0]= "open browser";
					 TestString[1]= "open application";
					 TestString[2]= "enter user name " ;
					 TestString[3]= "enter password";
					 TestString[4]= "enter token ID";
					 TestString[5]= "click submit";
					 TestString[6]= "navigate to settings";
					 TestString[7]= "verify settimgs";
					 TestString[8]= "close application";
					 TestString[9]= "close browser";
					 
					 for (int j = 0; j < TestString.length; j++) {
						 System.out.println(TestString[j]);
					 }		
					 
	//Problem 2.
					 
		TestCase1 testCase =new TestCase1();
		System.out.println(testCase.isFinished());
		try
		{
		testCase.run();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		System.out.println(testCase.isFinished());
		
		}
	
	
	
	}

