
public class Testcase {
	
	private String[] stArry=new String[10];
	private String description="How to make Tea? ";
	private boolean isFinished = false;
	
	
public boolean isFinished() {
		return isFinished;
	}
/* arrays*/
public Testcase() {	 
	 stArry[0] = "Step1: Bring half cup of water to boil   ";
	 stArry[1] = "Step2: Add a small piece of ginger and 1 cardomom."; 
	 stArry[2] = "Step3: Add 1 tea spoon of tea powder.";
	 stArry[3] = "Step4: Boil for 1 or 2 minutes.";
	 stArry[4] = "    Step5: Add half cup of milk.    ";
	 stArry[5] = "Step6: Wait till the tea comes to a boil.";
	 stArry[6] = "Step7: Turn off the stove.";
	 stArry[7] = "Step8: Add 1 or 2 tsp of sugar.";
	 stArry[8] = "Step9: Filter the tea into a cup.";
	 stArry[9] = "      Step10: Enjoy the hot cup of Tea :)";
	 
}

/*method, encapsulation and override*/
public void run() throws Exception{
	
	
	for(int x=0; x<10; x++)
	{
	
		System.out.println(stArry[x].trim());
	}
	isFinished= true;
	String Op= this.toString();
	System.out.println(Op);
	throw new Exception("\n All the test steps are complete");
	
}
@Override
public String toString() {
	String format = "Testcase{%s | number of steps: %d| complete: %b}";
	String output = String.format(format, description, stArry.length,isFinished);		
	return output;
	
}


}
