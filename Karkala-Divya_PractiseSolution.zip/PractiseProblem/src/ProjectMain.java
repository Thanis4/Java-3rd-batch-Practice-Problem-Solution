
public class ProjectMain {
	
	// ALL OTHER FUNCTIONS GO HERE
	
	//static String[] stArry=new String[10];
	//MAIN FUNCTION
	public static void main(String[] args) {
		
	
		 
		
//Problem 2		
	
	System.out.println("Divya Karkala");
	
	// no new line
	System.out.print("Divya");
	System.out.print(" Karkala");
	
	
//Problem 3
	
	int i = 5;
	float f = 6.0f;
	String s="abc";
	Boolean b= true;
	
	System.out.println("\ni=" +i );
	System.out.println("f=" +f);
	System.out.println("s="+s);
	System.out.println("b=" +b);
	
/* WRAPPER CLASSES */	
//Problem 1 and 2
	Integer in=new Integer(8);
	Float fl=new Float(3.0);
	String st=new String("def");
	Boolean bl=new Boolean(false);
	
	System.out.println("in=" +in.toString());
	System.out.println("fl=" +fl.toString());
	System.out.println("st=" +st.toString());
	System.out.println("bl=" +bl.toString());
	
/*LOOPS*/
//Problem 1 and 2
	for (int x=0; x<10;x++) 
	{
		System.out.println("Divya Karkala");
	}
	for (int x=0; x<10;x++)
	{
		System.out.println(+x);
	}
	
	for (int x=0;x<20;x++)
	{
		if(x >=10) {
		System.out.println(+x);
		}
		
	}
 for (int x=0;x<20;x++)
 {
	 if(bl==true) {
		 bl=false;
	 }
	 else {
		 bl=true;
	 }
 }
 /* methods,class and exception*/
 Testcase tc=new Testcase();

 System.out.println(tc.isFinished());
 
 try {
 tc.run();
 }
 catch(Exception e) {
	 System.out.println("An exception has triggered"+e.getMessage());
 }
 System.out.println(tc.isFinished()); 	 
 }

	
	

}
