import java.util.Iterator;

public class ProjectMain {
	
	static String[] testSteps = new String[10];
	
	public static void main(String[] args) 
	{
		//1. println vs print
		System.out.println("my name is : " );
		System.out.println ("Anca Morar" );
		
		System.out.print("my name is : ");
		System.out.println ("Anca Morar" );
		
		//2. variables1
		int anInt;
		float aFloat;
		String aString;
		boolean aBoolean;
		
		//2. variable2
		anInt = 12;
		aFloat = 2.3f;
		aString = "like to code";
		aBoolean = false;
		
		//2. variable3
		System.out.println("anInt="+ anInt);
		System.out.println("aFloat="+ aFloat);
		System.out.println("aString="+ aString);
		System.out.println("aBoolean="+ false);
		
		//3. wrapper classes1
		Integer anotherInt = new Integer(7);
		Float anotherFloat = new Float(5.6f);
		String anotherString = new String("write a code");
		Boolean anotherBoolean= new Boolean(true);
		
		//3. wrapper classes2
		System.out.println("anotherInt=" + anotherInt.toString());
		System.out.println("anotherFloat=" + anotherFloat.toString());
		System.out.println("anotherString=" + anotherString.toString());
		System.out.println("anotherBoolean=" + anotherBoolean.toString() );
		
		//4. loops1.
		System.out.println("----------------");
		System.out.println("4.loops1");
		int max=10;
		for (int i = 0; i < max; i++)
		{
			System.out.println("Anca Morar");
		}
		
		//4.Loops2
		System.out.println("----------------");
		System.out.println("4.Loops2");
		for (int i = 0; i < max; i++) 
		{
			System.out.println(i);
		}
		System.out.println("----------------");
		for (int i = 0; i <= 10; i++) 
		{
			System.out.println(i);
		}
		
		//5.if, if-else_1
		System.out.println("----------------");
		System.out.println("5.if/if-else_1");
		for (int i = 0; i <= 20; i++) 
		{
			if (i>=10)
			{
				System.out.println(i);
			}
		}
		
		//5.if, if-else_2
		System.out.println("----------------");
		System.out.println("5.if/if-else_2 ( i wanted to display the result)");
		boolean myBoolean = true;
		for (int i = 0; i < 20; i++) 
		{
			if (myBoolean == true) 
			{
				myBoolean = false;
			} 
			else 
			{
				myBoolean = true;
			}
			System.out.println(myBoolean);
			
		}
		
		//6. Arrays 
		System.out.println("----------------");
		System.out.println("6. Arrays ");
		
		testSteps[0] = "Step 1. use template";
		testSteps[1] = "Step 2. add details ";
		testSteps[2] = "Step 3. have walkthough";
		testSteps[3] = "Step 4. request approval";
		testSteps[4] = "Step 5. upload the confluence";
		testSteps[5] = "Step 6. send to project team";
		testSteps[6] = "Step 7. to environment team";
		testSteps[7] = "Step 8. test data team";
		testSteps[8] = "Step 9. update";
		testSteps[9] = "Step 10. final ";
		for (int i = 0; i < testSteps.length; i++) 
		{
			System.out.println(testSteps[i]);
		}
		
		// 9. encapsulation_2
		System.out.println("----------------");
		System.out.println("9. encapsulation");
		
		TestCase tc = new TestCase();
		System.out.println(tc.getIsFinished());
		try 
		{
			tc.run();
		} 
		catch (Exception ex) 
		{
			// TODO Auto-generated catch block
			//ex.printStackTrace();
			System.out.println("error : " + ex.getMessage());
		}
		System.out.println(tc.getIsFinished());
		
		System.out.println(tc.toString());
		
		}
	
		
		public void run () 
		{
		//7. methods / functions 
		System.out.println("----------------");
		System.out.println("7. methods/functions");
			for (int i = 0; i < testSteps.length; i++) 
			{
			System.out.println(testSteps[i]);	
			}
		}
		
		
		
	}


