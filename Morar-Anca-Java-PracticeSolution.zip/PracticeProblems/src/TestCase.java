import java.util.Arrays;

public class TestCase {

	private String description ="";
	private String[] testSteps = new String[10];
	private Boolean isFinished = false;

	//constructor
	public TestCase()
	{
		//8.classes
		System.out.println("----------------");
		System.out.println("8.classes ");
		testSteps[0] = "  Step 1. use template     ";
		testSteps[1] = "Step 2. add details ";
		testSteps[2] = "   Step 3. have walkthough";
		testSteps[3] = "Step 4. request approval";
		testSteps[4] = "Step 5. upload the confluence   ";
		testSteps[5] = "Step 6. send to project team";
		testSteps[6] = "Step 7. to environment team";
		testSteps[7] = "Step 8. test data team";
		testSteps[8] = "Step 9. update";
		testSteps[9] = "Step 10. final ";
	}

	// 9. encapsulation_1 .I exercised the get and set :) 
	
	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String[] getTestSteps() {
		return testSteps;
	}



	public void setTestSteps(String[] testSteps) {
		this.testSteps = testSteps;
	}



	public Boolean getIsFinished() 
	{
		return isFinished;
	}



	public void setIsFinished(Boolean isFinished) {
		this.isFinished = isFinished;
	}



	public void run() throws Exception 
	{
		for (int i = 0; i < testSteps.length; i++) 
		{
			System.out.println((testSteps[i]).trim());
		
		}
		isFinished = true;

//		Exception bla = new Exception ("all steps printed");
//		throw bla;
		throw new Exception ("all steps are completed ");
		
		
				
	}

	@Override
	public String toString() 
	{
		String patern = "TestCase {%S | number of steps : %d | complete : %b}";
		String toReturn = String.format(patern, description, testSteps.length, isFinished);
		return toReturn; 
		//return "TestCase [description=" + description + ", teststeps length =" + testSteps.length+ ", isFinished="
		//		+ isFinished + "]";
	}

	
	
	
	
}
