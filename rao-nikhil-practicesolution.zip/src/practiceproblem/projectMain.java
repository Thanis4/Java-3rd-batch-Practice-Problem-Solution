package practiceproblem;

public class projectMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Nikhil Rao");
		// Print sends text to the console and does not add a new line.
		// Println sends text to the console and adds a newline.
		//problem1
		int a;
		float b;
		String fruit;
		boolean flag;
		//problem 2
		a = 5;
		b = 10.5f;
		fruit = "apple";
		flag = true;
		
		//problem 3		
		System.out.println("An integer is "+ a);
		System.out.println("A float is "+ b);
		System.out.println("A String is "+ fruit);
		System.out.println("A boolean variable is "+ flag);
		
		//Wrapper classes problem
		// problem 1
		Integer aobj = new Integer(a);
		Float bobj = new Float(b);
		String fruitobj = new String(fruit);
		Boolean flagobj = new Boolean(flag);
		//problem 2
		System.out.println("An integer wrapper is "+ aobj.toString());	
		System.out.println("A float wrapper is "+ bobj.toString());
		System.out.println("A String wrapper is "+ fruitobj.toString());
		System.out.println("A boolean variable is "+ flagobj.toString());
		
		for (int i = 0; i < 10; i++)
		{ 
			System.out.println("Nikhil Rao");
		}
		
		for (int i = 0; i < 10; i++)
		{ 
			System.out.println(" after nikhilloop" +i);
		}
		
		
		
		// IF then  exercises
		// problem 1
		for (int i = 1; i <= 20; i++)
			
		{
		if (i >= 10)
		{
		System.out.println(i);
		}
		}
		// problem 2
		boolean myBoolean = true;
		for (int i = 1; i <= 20; i++)
		{
		if (myBoolean == true)
		{
		myBoolean = false;
		}
		else
		{
		myBoolean = true;
		}
		}
	
		
	

// ARRAYS  problem 1

String[] testSteps = new String[10];
testSteps[0] = "Step 1. Open a browser";
testSteps[1] = "Step 2. Navigate to http://www.walmart.com";
testSteps[2] = "Step 3. Search: LEE Jeans";
testSteps[3] = "Step 4. Validate the price at $25.00";
testSteps[4] = "Step 5. Click the Buy Now button";
testSteps[5] = "Step 6. Verify the INSTOCK checkmark";
testSteps[6] = "Step 7. Click the Go to Checkout! button";
testSteps[7] = "Step 8. Enter Billing and Shipping information";
testSteps[8] = "Step 9. Click Go to Checkout button";
testSteps[9] = "Step 10. Click the Submit Order button";
System.out.println(" reached end");
for (int i = 0; i < testSteps.length; i++)
{
	
System.out.println(testSteps[i]);

}

//METHOD Problem 1. make a function with the following signature: public void run()
//This function should loop through the array above and print each test step. This code will be used later.

//problem 2 with EXCEPTION
testcasemethod testcasemethod = new testcasemethod();
System.out.println(testcasemethod.isFinished());
// problem 2
try
{
testcasemethod.run();
}
catch (Exception e)
{
// problem 3
System.out.println(" An exception was triggered: " +
e.getMessage());
}
System.out.println(testcasemethod.isFinished());
	}}


