
public class TestCase {

	 private String[] TestSteps = new String[10];
	 private String description = "";
	 private boolean isFinished = false;
	 
	 {
	  TestSteps[0] = "   Step 1 : Open a browser and navigate to honestcompany site     ";
	  TestSteps[1] = "Step 2 : Login username and password .Click on Sign in button";
	  TestSteps[2] = "Step 3 : Click on order details buttons";
	  TestSteps[3] = "Step 4 : Click on Edit order button";
	  TestSteps[4] = "     Step 5 : Change the shiping date to July 31 ,2019      ";
	  TestSteps[5] = "Step 6 : Click on a Save button";
	  TestSteps[6] = "Step 7 : Click on Account details menu";
	  TestSteps[7] = "Step 8 : Opens a Account details page and click on Edit button";
	  TestSteps[8] = "    Step 9 : update the Card number, expire date and click on Save button     ";
	  TestSteps[9] = "Step 10 : Click on sign out button";
		}
	 
	 public void run() throws Exception
	 {
	 for (int i = 0; i < TestSteps.length; i++)
	 {
		 /// problem 2 : String manipulation
		 
	 System.out.println(TestSteps[i].trim());
	 }
	 isFinished = true;
	 
	 throw new Exception("All Test steps are completed");
	 }
	 public boolean isFinished()
	 {
	 return isFinished;
	 }
	 // problem 3
	 @Override
	 public String toString()
	 {
		 //problem 3:String manipulation
     String format = "TestCase{%s | number of steps:%d | complete: %b}";
     String output = String.format(format, description,TestSteps.length,isFinished);
	 //String output = description + " " + TestSteps.length + " " + isFinished;
	 return output;
	 }
	 }
