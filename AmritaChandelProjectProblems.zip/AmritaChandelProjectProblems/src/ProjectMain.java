
public class ProjectMain {
	
	static  String[] TestSteps = new String[10];
	   
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println("Amrita Chandel");
    System.out.print("Amrita Chandel");
    
    //In the console window the message will be and send and will not add a newline 
    //In the console window the message will be and send and will add a newline 
    
    //problem 1
    
    int anInt;
    float aFloat;
    String aString;
    boolean aBoolean;
     
    ///Problem 2
     
    anInt = 5;
    aFloat = 1.2f;
    aString = "nice weather";
    aBoolean = true;
    
    //Problem 3
    
    System.out.println("anInt: " + anInt );
    System.out.println("aFloat: " + aFloat );
    System.out.println("aString: " + aString );
    System.out.println("aBoolean: " + aBoolean );
  
    ///wrapper class
    
    ///problem 1
    
    Integer anotherInt = new Integer(anInt);
    Float anotherFloat = new Float(aFloat);
    String anotherString = new String (aString);
    Boolean anotherBoolean = new Boolean (aBoolean);
    
    ///problem 2
    
    System.out.println("anotherInt: " + anotherInt.toString());
    System.out.println("anotherFloat:" + anotherFloat.toString());
    System.out.println("anotherString :" + anotherString.toString());
    System.out.println("anotherBoolean:" + anotherBoolean.toString());
    
    
    ///Loops : For 
    
    //Problem 1
    
       
   for (int i = 0 ; i <10 ;  i++)
   {
     System.out.println("Amrita Chandel");
    
        	}
   
   ///Problem 2
   
   for (int i = 0 ; i <= 10 ;  i++)
   {
    System.out.println(i);
	
	}
   ///Loops : if/if else 
   
   ////Problem1
   
   
   for (int j = 1 ; j <= 20 ; j++)
   {
	   if (j>= 10)
	   {
		   System.out.println(j);
	   }
   }
	   
	   
   /// Problem 2
   
   Boolean cBoolean = true;
   
   for (int k = 1 ; k <= 20 ; k++)
   
   {
	   if (cBoolean == true)
	   {
		   cBoolean = false;
	   }
	   else
	   {
		   cBoolean = true;
	   }
	}
   
   ///Array
   
   /// Problem 1
   

   
   String[] TestSteps = new String[10];
   TestSteps[0] = "Step 1 : Open a browser and navigate to honestcompany site";
   TestSteps[1] = "Step 2 : Login username and password .Click on Sign in button";
   TestSteps[2] = "Step 3 : Click on order details buttons";
   TestSteps[3] = "Step 4 : Click on Edit order button";
   TestSteps[4] = "Step 5 : Change the shiping date to July 31 ,2019";
   TestSteps[5] = "Step 6 : Click on a Save button";
   TestSteps[6] = "Step 7 : Click on Account details menu";
   TestSteps[7] = "Step 8 : Opens a Account details page and click on Edit button";
   TestSteps[8] = "Step 9 : update the Card number, expire date and click on Save button";
   TestSteps[9] = "Step 10 : Click on sign out button";

   
   for(int i = 0 ; i< TestSteps.length; i++ )
   {
	   System.out.println(TestSteps[i]);
   }
		  
   /// methods/functions
   
   //Problem 1

   
//  TestSteps[0] = "Step 1 : Open a browser and navigate to honestcompany site";
//  TestSteps[1] = "Step 2 : Login username and password .Click on Sign in button";
//  TestSteps[2] = "Step 3 : Click on order details buttons";
//  TestSteps[3] = "Step 4 : Click on Edit order button";
//  TestSteps[4] = "Step 5 : Change the shiping date to July 31 ,2019";
//  TestSteps[5] = "Step 6 : Click on a Save button";
//  TestSteps[6] = "Step 7 : Click on Account details menu";
//  TestSteps[7] = "Step 8 : Opens a Account details page and click on Edit button";
//  TestSteps[8] = "Step 9 : update the Card number, expire date and click on Save button";
//  TestSteps[9] = "Step 10 : Click on sign out button";
//	}
//  public void run()
//   {
//  for(int i = 0 ; i< TestSteps.length; i++)
//  {
//	   System.out.println(TestSteps[i]);
//   }
// }
  
 //problem 2
   
   TestCase testcase = new TestCase();
   System.out.println(testcase.isFinished());
   try
   {
   testcase.run();
   }
   catch(Exception e)
   {
	// problem 3
	System.out.println(" An exception was triggered: " + e.getMessage());
	}
      
   System.out.println(testcase.isFinished());
   
	}

	
	
}
	



