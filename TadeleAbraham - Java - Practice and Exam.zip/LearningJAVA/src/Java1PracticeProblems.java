
public class Java1PracticeProblems {

	/**
	 * @param args
	 */

	static String[] testSteps = new String[10];
	
	
	public static void main(String[] args) {
		
		//writing messages to the �Console� window
		
		System.out.println("Message");
		//Problem 1 - System.out.println prints statement and moves the cursor to the next line
		System.out.println("Tadele");
		
		//Problem 2 - System.out.println prints statement and DOESN'T moves the cursor to the next line
		System.out.println("Tadele");
		
		
		//Problem 1 & 2 - Varibles 
		int X;
		float Y;
		String laptop;
		boolean SysON;
		
		//Problem 1 & 2 - Varibles 
		X =9;
		Y = 5.09f;
		laptop = "Lenovo";
		SysON = true;
		
		//Problem 3 - Varibles 
		
		System.out.println("An integer: " + X);
		System.out.println("A float: " + Y);
		System.out.println("A string: " + laptop);
		System.out.println("A boolean: " + SysON);
		
		//Problem 1 - wrapper classes
		
		Integer capX = 9;
		Float capY = 5.09f;
		String monitorType = "Dell";
		Boolean SysOFF = false;
		
		//Problem 2 - wrapper classes
		System.out.println("An integer: " + capX.toString());
		System.out.println("A float: " + capY.toString());
		System.out.println("A string: " + monitorType.toString());
		System.out.println("A boolean: " + SysOFF.toString());
		
		//Problem 1 - loops
		for (int i=0; i<10; i++) {
			System.out.println("Tadele");
		}
		
		//Problem 2 - loops
		
		for (int y=0; y<=9; y++) {
			System.out.println(y);
		}
		
		//Problem 1 - if/if-else 
		
		for (int x=1; x<=20; x++) {
			if (x>=10) {
				System.out.println(x);
			} 
			}
		//Problem 2 - if/if-else 
		
		boolean theBoolean = true;
		
		for (int i=1; i<=20; i++) {
			if( theBoolean == true) {
				
				theBoolean = false;
				}else {
				
					theBoolean = true;
				}
		}
		
		//Problem 1 - arrays
		
//		String[] testSteps = new String[10];
//		
//		testSteps[0] = "Step 1 -  Open Chrome";
//		testSteps[1] = "Step 2 -  Navigate to Costco.Ca";
//		testSteps[2] = "Step 3 -  Search: lenovo T470";
//		testSteps[3] = "Step 4 -  Check if laptop has 16G RAM";
//		testSteps[4] = "Step 5 -  Check if lapton has 500G of storage";
//		testSteps[5] = "Step 6 -  Select the add to cart button        ";
//		testSteps[6] = "Step 7 -  Select the BuyNow buttone";
//		testSteps[7] = "Step 8 -  Click checkout button";
//		testSteps[8] = "Step 9 -  Fill out payment and shipping information";
//		testSteps[9] = "Step 10 - Select order confirmation buttton          ";
//		
//		for (int i=0; i <testSteps.length; i++)	{	
//				System.out.println(testSteps[i]);
//		}
//	}	
//	// Problem 1 - methods/functions
//	
//	public void run() {
//		for (int i=0; i <testSteps.length; i++)	{	
//				System.out.println(testSteps[i]);
//				
//		}
	//Problem 2 - encapsulation 
	  
		TestCase1 testCase = new TestCase1();
		System.out.println(testCase.isFinished());
		
		//Problem 2 - exception handling 
		try 
		{
		testCase.run();	
		} 
		catch (Exception e)
		{
			
			//Problem 3 - exception handling 
			
		System.out.println("An exception was triggered: " + e.getMessage());
		}
		
		System.out.println(testCase.isFinished());
		
	}
	
}



		
	


