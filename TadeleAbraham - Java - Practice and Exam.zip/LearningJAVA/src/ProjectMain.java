
import java.util.ArrayList;
import java.util.List;

public class ProjectMain {

	public static void main(String[] args) {
		List<TestCase> testCases = new ArrayList<TestCase>();
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));
	

		
	 for (int i=0; i < 4; i++)  {
			
			//get the description from the testcase
			String tcDescription = testCases.get(i).getDescription();
					
			// get the test case number from the testcase
			int tcNumber = testCases.get(i).getTestCaseNumber();
			
			// setup a format for String.format to match the expected output for "Processing testcase" output
			String format = String.format("Processing testcase: %d: %s", tcNumber, tcDescription);
			// put the arguments for String.format in the correct order
			System.out.println(format);
			System.out.println(testCases.get(i).toString());
				
		
		}
		
	}
}



