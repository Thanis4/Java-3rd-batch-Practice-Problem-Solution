 
// Problem 1 - Classes

public class TestCase1 {
	private String[] testSteps = new String[10];	
	
	private String description = "";
	
	//Problem 1 - encapsulation
	
	private boolean isFinished = false;
	
	//Problem 1 - encapsulation 
		private void setFinished(boolean isFinished) {
		this.isFinished = isFinished;
	}
	
		
	public TestCase1()
	{
		//Problem 1 - string manipilation 
		
	testSteps[0] = "          Step 1 -  Open Chrome         ";
	testSteps[1] = "Step 2 -  Navigate to Costco.Ca          ";
	testSteps[2] = "           Step 3 -  Search: lenovo T470";
	testSteps[3] = "            Step 4 -  Check if laptop has 16G RAM";
	testSteps[4] = "Step 5 -  Check if lapton has 500G of storage";
	testSteps[5] = "          Step 6 -  Select the add to cart button";
	testSteps[6] = "Step 7 -  Select the BuyNow buttone         ";
	testSteps[7] = "Step 8 -  Click checkout button";
	testSteps[8] = "              Step 9 -  Fill out payment and shipping information";
	testSteps[9] = "Step 10 - Select order confirmation buttton";
	}
	
	public void run() {
		for (int i=0; i <testSteps.length; i++)	{	
				
			//Problem 2 - string manipulation
			
			System.out.println(testSteps[i].trim());
				
		}
		
		isFinished = true;
		
	}
	
	public boolean isFinished() {
		
	return isFinished;	
	}
	// Problem 3 - encapsulation
	
	@Override 
	public String toString() {
		String format = "TestCase{%s | numbers of steps: $d | complete: %b}";
		
		String output = String.format(format, description, testSteps.length, isFinished);
		
		return output;
	}
	
}

	